var helpApp=angular.module('HelpApp',['ngMessages','UtilityApp','ngMaterial','ui.router','ngAnimate']);
helpApp.run(function($rootScope) {
    $rootScope.organizationName="DAIMLER";

});
helpApp.config(function($mdThemingProvider) {
    $mdThemingProvider.theme('default')
        .dark();
});



helpApp.config(function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/tab/dash');
    $stateProvider
        .state('help', {
            url: "/help",
            templateUrl: "templates/issueTemplate.html",
            controller:"TicketController"
        })
        .state('support', {
            url: "/support",
            templateUrl: "templates/productSupport.html"
        })
       .state('dashboard', {
        url: "/dashboard",
        templateUrl: "templates/dashBoard.html"
    });

})