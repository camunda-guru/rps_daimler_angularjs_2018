helpApp.controller('TicketController',['$scope','types','CountryService',
    function($scope,types,CountryService)
{
    $scope.catTypes=types;
    $scope.countries=[];
  CountryService.countryServiceObj()
      .then(function(res)
    {
         angular.forEach(res.data,function(key,value)
        {
            console.log(key.name);
            $scope.countries.push(key.name);
        })
    })





    //model
    $scope.issue={
        employeeId:0,
        name:"",
        shortId:"",
        country:"",
        issueCategory:"",
        descr:""
    }
//submit event
    $scope.save=function()
    {
        console.log($scope.issue);
    }


}]);