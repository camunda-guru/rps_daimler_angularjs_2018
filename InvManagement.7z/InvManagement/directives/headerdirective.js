helpApp.directive('ngBenz',['configurable',function(configurable)
{

    return{
        restrict:'E',
        template:'<img src='+configurable.banner +' class="banner"/>' +
        '<img src='+configurable.logo +' class="logo"/>'
    };
}]);
