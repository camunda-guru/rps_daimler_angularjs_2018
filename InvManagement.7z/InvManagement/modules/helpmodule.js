var helpApp=angular.module('HelpApp',['ngMessages','UtilityApp',
    'ngMaterial','ui.router','ngAnimate','ui.grid',
    'ui.grid.exporter', 'ui.grid.selection','ui.grid.pagination',
    'ui.grid.edit','jkAngularCarousel']);
helpApp.run(function($rootScope) {
    $rootScope.organizationName="DAIMLER";

});
helpApp.config(function($mdThemingProvider) {
    $mdThemingProvider.theme('default')
        .dark();
});



helpApp.config(function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/tab/dash');
    $stateProvider
        .state('help', {
            url: "/help",
            templateUrl: "templates/issueTemplate.html",
            controller:"TicketController"
        })
        .state('escalations', {
            url: "/escalations",
            templateUrl: "templates/escalations.html",
            controller:"EscalationsController"
        })
       .state('dashboard', {
        url: "/dashboard",
        templateUrl: "templates/dashBoard.html",
        controller:"DashboardController"

    });

})


helpApp.provider('configurable',function()
{
    var Banner='';
    var Logo='';

    this.setBanner=function(value)
    {
        Banner=value;
    }
    this.setLogo=function(value)
    {
        Logo=value;
    }


    this.$get = function () {
        return {
            banner: Banner,
            logo:Logo
        };
    };

});

helpApp.config(function(configurableProvider)
{

    configurableProvider.setBanner("../resources/benz_banner.jpg");
    configurableProvider.setLogo("../resources/benz.jpg")
});




