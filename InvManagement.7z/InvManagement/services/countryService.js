utilityApp.service('CountryService',['$http',function($http)
{
    var countryList=function()
    {
        return $http({
            method: 'GET',
            dataType: "jsonp",

            headers: {
                'Content-Type': 'application/json'

            },
            url: 'https://restcountries.eu/rest/v2/all'
        });
    }

    return{
        countryServiceObj:countryList
    }

}]);