helpApp.controller('DashboardController',['$scope',function($scope)
{
    $scope.dataArray = [
        {
            src: '../resources/benz1.jpg'
        },
        {
            src: '../resources/benz2.jpg'
        },
        {
            src: '../resources/benz3.jpg'
        },
        {
            src: '../resources/benz4.jpg'
        },
        {
            src: '../resources/benz5.jpg'
        },
        {
            src: 'http://images.kuoni.co.uk/73/malaysia-21747826-1446726337-ImageGalleryLightbox.jpg'
        },
        {
            src: '../resources/benz.jpg'
        },
        {
            src: 'https://www.travcoa.com/sites/default/files/styles/flexslider_full/public/tours/images/imperialvietnam-halong-bay-14214576.jpg?itok=O-q1yr5_'
        }
    ];
}]);