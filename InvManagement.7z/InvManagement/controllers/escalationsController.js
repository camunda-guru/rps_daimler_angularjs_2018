helpApp.controller('EscalationsController',
    ['$scope','$rootScope',function($scope,$rootScope)
{
    $rootScope.gridOptions  = {};
    $scope.colDefs=[];

     $scope.escalations=[{
         "employeeId":248754,
         "name":"Anoop",
         "managerId":5376934,
         "doe":new Date(2018,2,2),
         "amount":378456
     },
         {
             "employeeId":7678954,
             "name":"Zahir",
             "managerId":6376934,
             "doe":new Date(2018,1,2),
             "amount":67890
         },
         {
             "employeeId":568754,
             "name":"Biju",
             "managerId":896934,
             "doe":new Date(2018,11,12),
             "amount":998456
         }]

    $scope.colDefs.push({
        field: "employeeId", displayName: "Employee Id",
        enableCellEdit: true,
        width: "*",
        resizable: false
    });
    $scope.colDefs.push({
        field: "name", displayName: "Escalated By",
        enableCellEdit: true,
        width: "*",
        resizable: false
    });
    $scope.colDefs.push({
        field: "managerId", displayName: "Escalated To",
        enableCellEdit: true,
        width: "*",
        resizable: false
    });

    $scope.colDefs.push({
        field: "doe", displayName: "Escalated Date",
        enableCellEdit: true,
        width: "*",
        resizable: false
    });
    $scope.colDefs.push({
        field: "amount", displayName: "Escalated Amount",
        enableCellEdit: true,
        width: "*",
        resizable: false
    });


    $rootScope.gridOptions ={
        data:$scope.escalations,
        columnDefs: $scope.colDefs,
        exporterMenuCsv: true,
        enableGridMenu: true,
        paginationPageSizes: [5, 10, 15],
        paginationPageSize: 2,
        useExternalPagination: true,
        useExternalSorting: true
    }


}])