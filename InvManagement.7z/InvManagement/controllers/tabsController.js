helpApp.controller('TabsController',['$scope','$location',
    function($scope,$location)
{

    $scope.selectedIndex = 0;

    $scope.$watch('selectedIndex', function(current, old) {
        switch (current) {
            case 0:
                $location.url("/help");
                break;
            case 1:
                $location.url("/escalations");
                break;
            case 2:
                $location.url("/dashboard");
                break;
        }
    });


}]);